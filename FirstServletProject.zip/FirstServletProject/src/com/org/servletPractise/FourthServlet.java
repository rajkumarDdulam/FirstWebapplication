package com.org.servletPractise;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FourthServlet
 */
@WebServlet("/FourthServlet")
public class FourthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");	
		PrintWriter pw=response.getWriter();
		
		String bb=(String) request.getAttribute("Uname");
		
		
		pw.write("<h1>Hello : </h1>");
		
		

		
		Cookie[] c1=request.getCookies();
		
		for(Cookie c2:c1){
			pw.write(c2.getValue());
			pw.write("<br>");
		}
		
		pw.write((String)request.getSession().getAttribute("FName"));
	}

}
