package com.org.servletPractise;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HideenFields extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("userName");
		
		response.setContentType("text/html");
		
		PrintWriter pw=response.getWriter();
		ServletContext sc=getServletContext();
		String abc=sc.getInitParameter("DriverName");
		
		pw.write(abc+" from Context Object");
		pw.write("</br>");
		
		pw.write("welcome "+name);
		
		pw.write("<form action='./serv6' method='post'>");
		pw.write("<input type='submit' value='submit'>");
		pw.write("<input type='hidden' name='hiddenName' value='"+name+"'/>");
		pw.write("</form>");
	}

}
