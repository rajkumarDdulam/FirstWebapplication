package com.org.servletPractise;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ServletSix extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	String name1=request.getParameter("userName");
	String name2=request.getParameter("hiddenName");
	
	PrintWriter pw=response.getWriter();
	
	pw.write("Hello : "+name1);
	pw.write("</br>");
	pw.write("Hello : "+name2);
	
	}

}
