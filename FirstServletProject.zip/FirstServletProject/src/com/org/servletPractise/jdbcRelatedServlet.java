package com.org.servletPractise;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class jdbcRelatedServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
	Statement state=null;
	
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		
		
		PrintWriter pw=response.getWriter();
		pw.write("<h1> Employee Details: </h1>");
		pw.write("</br>");
		jdbcConnection();
		String query1="select * from firsttable";
		try {
			ResultSet rs=state.executeQuery(query1);
			
			while(rs.next()){
				
				String name1=rs.getString(1);
				pw.write("Name is : "+name1);
				
				pw.write("</br>");

				
				int id=rs.getInt(2);
				pw.write("Id is : "+id);
				pw.write("</br>");

				String adres=rs.getString(3);
				pw.write("Address is : "+adres);
				pw.write("</br>");
				pw.write("</br>");
				pw.write("</br>");

			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void jdbcConnection(){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcconnection", "root", "root");
			state=con.createStatement();
			
		
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
