package com.org.servletPractise;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;


public class seconServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		response.setContentType("text/html");
		
		
		String Fname=request.getParameter("Uname");
		Cookie cock=new Cookie("UserName", Fname);


		
		PrintWriter pw=response.getWriter();
		
		
		request.setAttribute("ServletAttributeName", "Fucking");
		if(Fname.equalsIgnoreCase("Raj")){
			response.addCookie(cock);
		 HttpSession ses=request.getSession();
		 
		 ses.setAttribute("FName", "Rajkumar");
		 ses.setAttribute("LName", "Dulam");

		 ses.setAttribute("Address", "4020 Woodland Plaza Des Moines");

			RequestDispatcher rd=request.getRequestDispatcher("/thirdServlet");
			
			rd.forward(request, response);
			
		}
		else{
			pw.write("Wrong Username. Please enter the Correct Credentials");
			RequestDispatcher rd=request.getRequestDispatcher("/firstForm.html");

		rd.include(request, response);

		}
	}

}
